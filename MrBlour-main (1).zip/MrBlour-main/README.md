<div align="center">
  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.herokuapp.com?font=Roboto&weight=500&size=30&pause=900&color=F7004BFF&center=true&vCenter=true&repeat=true&width=435&lines=Hello+how+are+you!;Welcome+to+my+profile;I'm+MrBlour" alt="Typing SVG" />
  </a>
</div>

<h3 align="center">I am a young Software Developer and Graphic Designer</h3>

<br/>

<div align="center">
  CEO of Bautic Studios, Cosly Studios and Novation Hosting. Get our services with total security and confidence.
  <br/>
  Graphic design - Development (Bots and Plugins) - Configured (Discord and Minecraft)
  <br/>
  MySql data center management - Graphic designer
</div>

<h2 align="center">  </h2>

<div align="center">
    <img src="https://skillicons.dev/icons?i=java,nodejs,idea,vscode,html,css,php,bots,discord,ps,ae,ai,bash,eclipse,figma,github,js,mysql" />
</div>
